<?php

namespace Square\Table;

use Zend\Db\TableGateway\TableGateway;

class SquareMetaTable extends TableGateway
{

    const NAME = 'bs_squares_meta';

}