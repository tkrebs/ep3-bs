<?php

namespace User\Table;

use Zend\Db\TableGateway\TableGateway;

class UserTable extends TableGateway
{

    const NAME = 'bs_users';

}