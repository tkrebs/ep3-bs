<?php

namespace Booking\Table;

use Zend\Db\TableGateway\TableGateway;

class ReservationMetaTable extends TableGateway
{

    const NAME = 'bs_reservations_meta';

}