<?php

namespace Booking\Table;

use Zend\Db\TableGateway\TableGateway;

class BookingTable extends TableGateway
{

    const NAME = 'bs_bookings';

}