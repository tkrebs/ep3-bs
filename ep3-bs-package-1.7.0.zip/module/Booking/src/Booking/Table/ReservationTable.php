<?php

namespace Booking\Table;

use Zend\Db\TableGateway\TableGateway;

class ReservationTable extends TableGateway
{

    const NAME = 'bs_reservations';

}