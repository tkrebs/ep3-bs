<?php

return array(

    'ep-3 Bookingsystem' => 'ep-3 Système de réservation',
    'ep-3 Bookingsystem Setup' => 'ep-3 ep-3 Système de réservation - Installation',

    'imgs/branding/ep3-bs-neg-en.png' => 'imgs/branding/ep3-bs-neg-en.png',

);