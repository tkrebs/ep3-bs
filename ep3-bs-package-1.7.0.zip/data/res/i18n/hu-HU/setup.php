<?php

return array(

    'ep-3 Bookingsystem' => 'ep-3 Foglalási rendszer',
    'ep-3 Bookingsystem Setup' => 'ep-3 Foglalási rendszer beállítás',

    'imgs/branding/ep3-bs-neg-en.png' => 'imgs/branding/ep3-bs-neg-en.png',

);
