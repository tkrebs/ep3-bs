<?php

return array(

    'Today' => 'Ma',
    'Date' => 'Dátum',
    'Time' => 'Idő',
    'Show' => 'Mutasd',

    'To book %s, %splease register first%s' => 'A %s foglalásához, %skérem itt regisztráljon%s',
    'or simply %s login here' => 'vagy egyszerűen %s lépjen be itt',

    'Email address' => 'Email cím',
    'Email' => 'Email',
    'Phone' => 'Telefon',
    'Password' => 'Jelszó',
    'Login' => 'Belépés',
    'Logout' => 'Kilépés',

    'New password' => 'Új jelszó',

    'Get additional %shelp and information%s' => 'Több %ssegítség és információ%s kérése',

    'Online as %s' => 'Belépve mint %s',

    'Administration' => 'Adminisztráció',

    'My bookings' => 'Foglalásaim',
    'My account' => 'Fiókom',

);
