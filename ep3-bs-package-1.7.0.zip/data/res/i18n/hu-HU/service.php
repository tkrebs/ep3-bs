<?php

return array(

    'System status' => 'Rendszer státusz',
    'Maintenance' => 'Karbantartás',

    'Help' => 'Segítség',

    'We are currently working on this page.' => 'Jelenleg ez a lap fejlesztés alatt áll.',

    'The system is currently not available' => 'A rendszer jelenleg nem elérhető',
    'System maintenance underway' => 'Rendszer karbantartás folyamatban',
    'We are back as fast as we can. Promised!' => 'A rendszer hamarosan elérhető!',

    'The system is available' => 'A rendszer elérhető',

);